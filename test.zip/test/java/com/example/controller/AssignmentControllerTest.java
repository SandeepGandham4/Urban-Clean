package com.example.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.dto.AssignmentDto;
import com.example.exception.DuplicateResourceException;
import com.example.exception.GlobalExceptionHandler;
import com.example.exception.ResourceNotFoundException;
import com.example.service.AssignmentService;
import com.fasterxml.jackson.databind.ObjectMapper;

class AssignmentControllerTest {

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Mock
    private AssignmentService assignmentService;

    @InjectMocks
    private AssignmentController assignmentController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(assignmentController)
                .setControllerAdvice(new GlobalExceptionHandler()) // Include GlobalExceptionHandler
                .build();
        objectMapper.findAndRegisterModules(); // Ensures proper serialization
    }

    @Test
    void testCreateAssignment() throws Exception {
        AssignmentDto.AssignmentCreateRequest request = new AssignmentDto.AssignmentCreateRequest();
        request.setVehicleId(1L);
        request.setRouteId(2L);
        request.setDateAssigned(LocalDate.now());

        AssignmentDto.AssignmentResponse response = new AssignmentDto.AssignmentResponse();
        response.setAssignmentId(1L);
        response.setVehicleId(1L);
        response.setRouteId(2L);
        response.setDateAssigned(LocalDate.now());

        when(assignmentService.createAssignment(any())).thenReturn(response);

        mockMvc.perform(post("/api/urbanclean/v1/assignments")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.assignmentId").value(1L))
                .andExpect(jsonPath("$.vehicleId").value(1L))
                .andExpect(jsonPath("$.routeId").value(2L));

        verify(assignmentService).createAssignment(any());
    }

    @Test
    void testGetAssignmentsByDate() throws Exception {
        LocalDate date = LocalDate.now();
        AssignmentDto.AssignmentResponse response = new AssignmentDto.AssignmentResponse();
        response.setAssignmentId(1L);
        response.setVehicleId(1L);
        response.setRouteId(2L);
        response.setDateAssigned(date);

        List<AssignmentDto.AssignmentResponse> responses = Arrays.asList(response);

        when(assignmentService.getAssignmentsByDate(date)).thenReturn(responses);

        mockMvc.perform(get("/api/urbanclean/v1/assignments")
                .param("date", date.toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].assignmentId").value(1L));

        verify(assignmentService).getAssignmentsByDate(date);
    }

    @Test
    void testGetAllAssignments() throws Exception {
        AssignmentDto.AssignmentResponse response = new AssignmentDto.AssignmentResponse();
        response.setAssignmentId(1L);
        response.setVehicleId(1L);
        response.setRouteId(2L);
        response.setDateAssigned(LocalDate.now());

        List<AssignmentDto.AssignmentResponse> responses = Arrays.asList(response);

        when(assignmentService.getAllAssignments()).thenReturn(responses);

        mockMvc.perform(get("/api/urbanclean/v1/assignments"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].assignmentId").value(1L));

        verify(assignmentService).getAllAssignments();
    }

    @Test
    void testGetAssignmentById() throws Exception {
        AssignmentDto.AssignmentResponse response = new AssignmentDto.AssignmentResponse();
        response.setAssignmentId(1L);
        response.setVehicleId(1L);
        response.setRouteId(2L);
        response.setDateAssigned(LocalDate.now());

        when(assignmentService.getAssignmentById(1L)).thenReturn(response);

        mockMvc.perform(get("/api/urbanclean/v1/assignments/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.assignmentId").value(1L));

        verify(assignmentService).getAssignmentById(1L);
    }

    @Test
    void testUpdateAssignment() throws Exception {
        AssignmentDto.AssignmentUpdateRequest request = new AssignmentDto.AssignmentUpdateRequest();
        request.setRouteId(2L);
        request.setDateAssigned(LocalDate.now());

        AssignmentDto.AssignmentResponse response = new AssignmentDto.AssignmentResponse();
        response.setAssignmentId(1L);
        response.setVehicleId(1L);
        response.setRouteId(2L);
        response.setDateAssigned(LocalDate.now());

        when(assignmentService.updateAssignment(eq(1L), any())).thenReturn(response);

        mockMvc.perform(put("/api/urbanclean/v1/assignments/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.assignmentId").value(1L))
                .andExpect(jsonPath("$.routeId").value(2L));

        verify(assignmentService).updateAssignment(eq(1L), any());
    }

    @Test
    void testDeleteAssignment() throws Exception {
        doNothing().when(assignmentService).deleteAssignment(1L);

        mockMvc.perform(delete("/api/urbanclean/v1/assignments/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Assignment with ID 1 has been successfully deleted."));

        verify(assignmentService).deleteAssignment(1L);
    }
    
    @Test
    void testCreateAssignmentThrowsDuplicateResourceException() throws Exception {
        // Arrange
        AssignmentDto.AssignmentCreateRequest request = new AssignmentDto.AssignmentCreateRequest();
        request.setVehicleId(1L);
        request.setRouteId(2L);
        request.setDateAssigned(LocalDate.now());

        doThrow(new DuplicateResourceException("Assignment already exists for the given route and date."))
                .when(assignmentService).createAssignment(any());

        // Act & Assert
        mockMvc.perform(post("/api/urbanclean/v1/assignments")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.message").value("Assignment already exists for the given route and date."));

        verify(assignmentService).createAssignment(any());
    }
    
    @Test
    void testGetAssignmentsByDateThrowsResourceNotFoundException() throws Exception {
        // Arrange
        LocalDate date = LocalDate.now();

        doThrow(new ResourceNotFoundException("No assignments found for the given date."))
                .when(assignmentService).getAssignmentsByDate(date);

        // Act & Assert
        mockMvc.perform(get("/api/urbanclean/v1/assignments")
                .param("date", date.toString()))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("No assignments found for the given date."));

        verify(assignmentService).getAssignmentsByDate(date);
    }
    
    @Test
    void testGetAssignmentByIdThrowsResourceNotFoundException() throws Exception {
        // Arrange
        Long assignmentId = 1L;

        doThrow(new ResourceNotFoundException("Assignment not found with ID: " + assignmentId))
                .when(assignmentService).getAssignmentById(assignmentId);

        // Act & Assert
        mockMvc.perform(get("/api/urbanclean/v1/assignments/{assignmentId}", assignmentId))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Assignment not found with ID: " + assignmentId));

        verify(assignmentService).getAssignmentById(assignmentId);
    }
    
    @Test
    void testUpdateAssignmentThrowsResourceNotFoundException() throws Exception {
        // Arrange
        Long assignmentId = 1L;
        AssignmentDto.AssignmentUpdateRequest request = new AssignmentDto.AssignmentUpdateRequest();
        request.setRouteId(2L);
        request.setDateAssigned(LocalDate.now());

        doThrow(new ResourceNotFoundException("Assignment not found with ID: " + assignmentId))
                .when(assignmentService).updateAssignment(eq(assignmentId), any());

        // Act & Assert
        mockMvc.perform(put("/api/urbanclean/v1/assignments/{assignmentId}", assignmentId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Assignment not found with ID: " + assignmentId));

        verify(assignmentService).updateAssignment(eq(assignmentId), any());
    }
    
    @Test
    void testDeleteAssignmentThrowsResourceNotFoundException() throws Exception {
        // Arrange
        Long assignmentId = 1L;

        doThrow(new ResourceNotFoundException("Assignment not found with ID: " + assignmentId))
                .when(assignmentService).deleteAssignment(assignmentId);

        // Act & Assert
        mockMvc.perform(delete("/api/urbanclean/v1/assignments/{assignmentId}", assignmentId))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Assignment not found with ID: " + assignmentId));

        verify(assignmentService).deleteAssignment(assignmentId);
    }
}