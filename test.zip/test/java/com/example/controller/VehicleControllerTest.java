package com.example.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.dto.VehicleDto;
import com.example.exception.GlobalExceptionHandler;
import com.example.exception.ResourceNotFoundException;
import com.example.service.VehicleService;
import com.fasterxml.jackson.databind.ObjectMapper;

class VehicleControllerTest {

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Mock
    private VehicleService vehicleService;

    @InjectMocks
    private VehicleController vehicleController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(vehicleController)
                .setControllerAdvice(new GlobalExceptionHandler()) // Include GlobalExceptionHandler
                .build();
        objectMapper.findAndRegisterModules(); // Ensures proper serialization
    }

    @Test
    void testCreateVehicle() throws Exception {
        VehicleDto.VehicleCreateRequest request = new VehicleDto.VehicleCreateRequest();
        request.setRegistrationNo("ABC123");
        request.setType("Truck");
        request.setStatus("Available");

        VehicleDto.VehicleResponse response = new VehicleDto.VehicleResponse();
        response.setVehicleId(1L);
        response.setRegistrationNo("ABC123");
        response.setType("Truck");
        response.setStatus("Available");

        when(vehicleService.createVehicle(any())).thenReturn(response);

        mockMvc.perform(post("/api/urbanclean/v1/vehicles")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.vehicleId").value(1L))
                .andExpect(jsonPath("$.registrationNo").value("ABC123"))
                .andExpect(jsonPath("$.type").value("Truck"))
                .andExpect(jsonPath("$.status").value("Available"));

        verify(vehicleService).createVehicle(any());
    }

    @Test
    void testGetAllVehicles() throws Exception {
        VehicleDto.VehicleResponse response = new VehicleDto.VehicleResponse();
        response.setVehicleId(1L);
        response.setRegistrationNo("ABC123");
        response.setType("Truck");
        response.setStatus("Available");

        List<VehicleDto.VehicleResponse> responses = Arrays.asList(response);

        when(vehicleService.getAllVehicles()).thenReturn(responses);

        mockMvc.perform(get("/api/urbanclean/v1/vehicles"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].vehicleId").value(1L))
                .andExpect(jsonPath("$[0].registrationNo").value("ABC123"))
                .andExpect(jsonPath("$[0].type").value("Truck"))
                .andExpect(jsonPath("$[0].status").value("Available"));

        verify(vehicleService).getAllVehicles();
    }

    @Test
    void testGetVehicleById() throws Exception {
        VehicleDto.VehicleResponse response = new VehicleDto.VehicleResponse();
        response.setVehicleId(1L);
        response.setRegistrationNo("ABC123");
        response.setType("Truck");
        response.setStatus("Available");

        when(vehicleService.getVehicleById(1L)).thenReturn(response);

        mockMvc.perform(get("/api/urbanclean/v1/vehicles/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.vehicleId").value(1L))
                .andExpect(jsonPath("$.registrationNo").value("ABC123"))
                .andExpect(jsonPath("$.type").value("Truck"))
                .andExpect(jsonPath("$.status").value("Available"));

        verify(vehicleService).getVehicleById(1L);
    }

    @Test
    void testGetVehicleStatus() throws Exception {
        VehicleDto.VehicleStatusResponse response = new VehicleDto.VehicleStatusResponse();
        response.setStatus("Available");

        when(vehicleService.getVehicleStatus(1L)).thenReturn(response);

        mockMvc.perform(get("/api/urbanclean/v1/vehicles/1/status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("Available"));

        verify(vehicleService).getVehicleStatus(1L);
    }

    @Test
    void testUpdateVehicle() throws Exception {
        VehicleDto.VehicleUpdateRequest request = new VehicleDto.VehicleUpdateRequest();
        request.setRegistrationNo("XYZ789");
        request.setType("Van");

        VehicleDto.VehicleResponse response = new VehicleDto.VehicleResponse();
        response.setVehicleId(1L);
        response.setRegistrationNo("XYZ789");
        response.setType("Van");
        response.setStatus("Available");

        when(vehicleService.updateVehicle(eq(1L), any())).thenReturn(response);

        mockMvc.perform(put("/api/urbanclean/v1/vehicles/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.vehicleId").value(1L))
                .andExpect(jsonPath("$.registrationNo").value("XYZ789"))
                .andExpect(jsonPath("$.type").value("Van"))
                .andExpect(jsonPath("$.status").value("Available"));

        verify(vehicleService).updateVehicle(eq(1L), any());
    }

    @Test
    void testTransferAndDeleteVehicleWithoutTransfer() throws Exception {
        doNothing().when(vehicleService).transferAndDeleteVehicle(1L, null);

        mockMvc.perform(delete("/api/urbanclean/v1/vehicles/1/transfer"))
                .andExpect(status().isOk())
                .andExpect(content().string("Vehicle with ID 1 has been successfully deleted."));

        verify(vehicleService).transferAndDeleteVehicle(1L, null);
    }

    @Test
    void testTransferAndDeleteVehicleWithTransfer() throws Exception {
        doNothing().when(vehicleService).transferAndDeleteVehicle(1L, 2L);

        mockMvc.perform(delete("/api/urbanclean/v1/vehicles/1/transfer?toVehicleId=2"))
                .andExpect(status().isOk())
                .andExpect(content().string("Assignments have been successfully transferred from vehicle ID 1 to vehicle ID 2, and vehicle ID 1 has been deleted."));

        verify(vehicleService).transferAndDeleteVehicle(1L, 2L);
    }

    @Test
    void testUpdateVehicleLocationStatus() throws Exception {
        VehicleDto.VehicleStatusUpdateRequest request = new VehicleDto.VehicleStatusUpdateRequest();
        request.setNewStatus("Inactive");

        VehicleDto.VehicleResponse response = new VehicleDto.VehicleResponse();
        response.setVehicleId(1L);
        response.setRegistrationNo("ABC123");
        response.setType("Truck");
        response.setStatus("Inactive");

        when(vehicleService.updateVehicleStatus(eq(1L), any())).thenReturn(response);

        mockMvc.perform(put("/api/urbanclean/v1/vehicles/1/status")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.vehicleId").value(1L))
                .andExpect(jsonPath("$.registrationNo").value("ABC123"))
                .andExpect(jsonPath("$.type").value("Truck"))
                .andExpect(jsonPath("$.status").value("Inactive"));

        verify(vehicleService).updateVehicleStatus(eq(1L), any());
    }
    
    @Test
    void testCreateVehicleWithInvalidInput() throws Exception {
        // Arrange
        VehicleDto.VehicleCreateRequest request = new VehicleDto.VehicleCreateRequest();
        // Missing required fields (e.g., registrationNo, type)

        // Act & Assert
        mockMvc.perform(post("/api/urbanclean/v1/vehicles")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.registrationNo").exists())
                .andExpect(jsonPath("$.errors.type").exists());
    }

    @Test
    void testGetVehicleByIdThrowsResourceNotFoundException() throws Exception {
        // Arrange
        Long vehicleId = 1L;

        doThrow(new ResourceNotFoundException("Vehicle not found with ID: " + vehicleId))
                .when(vehicleService).getVehicleById(vehicleId);

        // Act & Assert
        mockMvc.perform(get("/api/urbanclean/v1/vehicles/{vehicleId}", vehicleId))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Vehicle not found with ID: " + vehicleId));

        verify(vehicleService).getVehicleById(vehicleId);
    }

    @Test
    void testGetVehicleStatusThrowsResourceNotFoundException() throws Exception {
        // Arrange
        Long vehicleId = 1L;

        doThrow(new ResourceNotFoundException("Vehicle not found with ID: " + vehicleId))
                .when(vehicleService).getVehicleStatus(vehicleId);

        // Act & Assert
        mockMvc.perform(get("/api/urbanclean/v1/vehicles/{vehicleId}/status", vehicleId))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Vehicle not found with ID: " + vehicleId));

        verify(vehicleService).getVehicleStatus(vehicleId);
    }

    @Test
    void testUpdateVehicleThrowsResourceNotFoundException() throws Exception {
        // Arrange
        Long vehicleId = 1L;
        VehicleDto.VehicleUpdateRequest request = new VehicleDto.VehicleUpdateRequest();
        request.setRegistrationNo("XYZ789");
        request.setType("Van");

        doThrow(new ResourceNotFoundException("Vehicle not found with ID: " + vehicleId))
                .when(vehicleService).updateVehicle(eq(vehicleId), any());

        // Act & Assert
        mockMvc.perform(put("/api/urbanclean/v1/vehicles/{vehicleId}", vehicleId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Vehicle not found with ID: " + vehicleId));

        verify(vehicleService).updateVehicle(eq(vehicleId), any());
    }


    @Test
    void testTransferAndDeleteVehicleThrowsResourceNotFoundException() throws Exception {
        // Arrange
        Long vehicleId = 1L;

        doThrow(new ResourceNotFoundException("Vehicle not found with ID: " + vehicleId))
                .when(vehicleService).transferAndDeleteVehicle(vehicleId, null);

        // Act & Assert
        mockMvc.perform(delete("/api/urbanclean/v1/vehicles/{vehicleId}/transfer", vehicleId))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Vehicle not found with ID: " + vehicleId));

        verify(vehicleService).transferAndDeleteVehicle(vehicleId, null);
    }

    @Test
    void testUpdateVehicleLocationStatusThrowsResourceNotFoundException() throws Exception {
        // Arrange
        Long vehicleId = 1L;
        VehicleDto.VehicleStatusUpdateRequest request = new VehicleDto.VehicleStatusUpdateRequest();
        request.setNewStatus("Inactive");

        doThrow(new ResourceNotFoundException("Vehicle not found with ID: " + vehicleId))
                .when(vehicleService).updateVehicleStatus(eq(vehicleId), any());

        // Act & Assert
        mockMvc.perform(put("/api/urbanclean/v1/vehicles/{vehicleId}/status", vehicleId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Vehicle not found with ID: " + vehicleId));

        verify(vehicleService).updateVehicleStatus(eq(vehicleId), any());
    }

    @Test
    void testUpdateVehicleLocationStatusWithInvalidInput() throws Exception {
        // Arrange
        Long vehicleId = 1L;
        VehicleDto.VehicleStatusUpdateRequest request = new VehicleDto.VehicleStatusUpdateRequest();
        // Missing required fields (e.g., newStatus)

        // Act & Assert
        mockMvc.perform(put("/api/urbanclean/v1/vehicles/{vehicleId}/status", vehicleId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.newStatus").exists());
    }
}