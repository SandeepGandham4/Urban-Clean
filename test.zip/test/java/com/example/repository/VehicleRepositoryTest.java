package com.example.repository;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.entity.Vehicle;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
class VehicleRepositoryTest {

    @Autowired
    private VehicleRepository vehicleRepository;

    @Test
    void testExistsByRegistrationNo() {
        // Arrange
        Vehicle vehicle = new Vehicle();
        vehicle.setRegistrationNo("ABC123");
        vehicle.setType("Truck");
        vehicle.setStatus("Available");
        vehicleRepository.save(vehicle);
 
        // Act
        boolean exists = vehicleRepository.existsByRegistrationNo("ABC123");

        // Assert
        assertTrue(exists, "Vehicle with registration number 'ABC123' should exist");
    }

    @Test
    void testDoesNotExistByRegistrationNo() {
        // Act
        boolean exists = vehicleRepository.existsByRegistrationNo("XYZ789");

        // Assert
        assertFalse(exists, "Vehicle with registration number 'XYZ789' should not exist");
    }
}