package com.example.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.entity.Assignment;
import com.example.entity.Vehicle;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
class AssignmentRepositoryTest {

    @Autowired
    private AssignmentRepository assignmentRepository;

    @Autowired
    private VehicleRepository vehicleRepository; // Assuming you have a VehicleRepository

    private Vehicle testVehicle;

    @BeforeEach
    void setUp() {
        // Create and save a test vehicle
        testVehicle = new Vehicle();
        testVehicle.setRegistrationNo("ABC123");
        testVehicle.setType("Truck");
        testVehicle.setStatus("Active");
        testVehicle = vehicleRepository.save(testVehicle);

        // Create and save test assignments
        Assignment assignment1 = new Assignment();
        assignment1.setVehicle(testVehicle);
        assignment1.setRouteId(1L);
        assignment1.setDateAssigned(LocalDate.now());
        assignmentRepository.save(assignment1);

        Assignment assignment2 = new Assignment();
        assignment2.setVehicle(testVehicle);
        assignment2.setRouteId(2L);
        assignment2.setDateAssigned(LocalDate.now().plusDays(1));
        assignmentRepository.save(assignment2);
    }

    @Test
    void testFindByDateAssigned() {
        LocalDate today = LocalDate.now();
        List<Assignment> assignments = assignmentRepository.findByDateAssigned(today);

        assertNotNull(assignments);
        assertFalse(assignments.isEmpty());
        for (Assignment assignment : assignments) {
            assertEquals(today, assignment.getDateAssigned());
        }
    }

    @Test
    void testFindByVehicle() {
        List<Assignment> assignments = assignmentRepository.findByVehicle(testVehicle);

        assertNotNull(assignments);
        assertFalse(assignments.isEmpty());
        for (Assignment assignment : assignments) {
            assertEquals(testVehicle, assignment.getVehicle());
        }
    }

    @Test
    void testExistsByRouteIdAndDateAssigned() {
        boolean exists = assignmentRepository.existsByRouteIdAndDateAssigned(1L, LocalDate.now());

        assertTrue(exists);
    }

    @Test
    void testExistsByVehicleVehicleIdAndDateAssigned() {
        boolean exists = assignmentRepository.existsByVehicle_VehicleIdAndDateAssigned(testVehicle.getVehicleId(), LocalDate.now());

        assertTrue(exists);
    }
}