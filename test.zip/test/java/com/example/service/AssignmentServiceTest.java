package com.example.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.dto.AssignmentDto;
import com.example.entity.Assignment;
import com.example.entity.Vehicle;
import com.example.exception.DuplicateResourceException;
import com.example.exception.InvalidRequestException;
import com.example.exception.ResourceNotFoundException;
import com.example.repository.AssignmentRepository;
import com.example.repository.VehicleRepository;

class AssignmentServiceTest {

    @Mock
    private AssignmentRepository assignmentRepository;

    @Mock
    private VehicleRepository vehicleRepository;

    @InjectMocks
    private AssignmentService assignmentService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateAssignment() {
        // Arrange
        AssignmentDto.AssignmentCreateRequest request = new AssignmentDto.AssignmentCreateRequest();
        request.setRouteId(1L);
        request.setDateAssigned(LocalDate.now());
        request.setVehicleId(1L);

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setRegistrationNo("ABC123");

        Assignment assignment = new Assignment();
        assignment.setAssignmentId(1L);
        assignment.setRouteId(1L);
        assignment.setDateAssigned(LocalDate.now());
        assignment.setVehicle(vehicle);

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));
        when(assignmentRepository.existsByRouteIdAndDateAssigned(1L, LocalDate.now())).thenReturn(false);
        when(assignmentRepository.save(any(Assignment.class))).thenReturn(assignment);

        // Act
        AssignmentDto.AssignmentResponse response = assignmentService.createAssignment(request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getAssignmentId()).isEqualTo(1L);
        assertThat(response.getRouteId()).isEqualTo(1L);
        assertThat(response.getVehicleId()).isEqualTo(1L);
        verify(vehicleRepository).findById(1L);
        verify(assignmentRepository).existsByRouteIdAndDateAssigned(1L, LocalDate.now());
        verify(assignmentRepository).save(any(Assignment.class));
    }

    @Test
    void testCreateAssignmentThrowsDuplicateResourceException() {
        // Arrange
        AssignmentDto.AssignmentCreateRequest request = new AssignmentDto.AssignmentCreateRequest();
        request.setRouteId(1L);
        request.setDateAssigned(LocalDate.now());
        request.setVehicleId(1L);

        when(assignmentRepository.existsByRouteIdAndDateAssigned(1L, LocalDate.now())).thenReturn(true);

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.createAssignment(request))
                .isInstanceOf(DuplicateResourceException.class)
                .hasMessageContaining("An assignment with the same routeId 1 and date assigned");
        verify(assignmentRepository).existsByRouteIdAndDateAssigned(1L, LocalDate.now());
        verifyNoInteractions(vehicleRepository);
    }

    @Test
    void testGetAssignmentsByDate() {
        // Arrange
        LocalDate date = LocalDate.now();
        Assignment assignment = new Assignment();
        assignment.setAssignmentId(1L);
        assignment.setRouteId(1L);
        assignment.setDateAssigned(date);

        when(assignmentRepository.findByDateAssigned(date)).thenReturn(List.of(assignment));

        // Act
        List<AssignmentDto.AssignmentResponse> responses = assignmentService.getAssignmentsByDate(date);

        // Assert
        assertThat(responses).isNotEmpty();
        assertThat(responses.get(0).getAssignmentId()).isEqualTo(1L);
        verify(assignmentRepository).findByDateAssigned(date);
    }

    @Test
    void testGetAssignmentsByDateThrowsResourceNotFoundException() {
        // Arrange
        LocalDate date = LocalDate.now();
        when(assignmentRepository.findByDateAssigned(date)).thenReturn(List.of());

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.getAssignmentsByDate(date))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("No assignments found for the date");
        verify(assignmentRepository).findByDateAssigned(date);
    }

    @Test
    void testGetAllAssignments() {
        // Arrange
        Assignment assignment = new Assignment();
        assignment.setAssignmentId(1L);
        assignment.setRouteId(1L);
        assignment.setDateAssigned(LocalDate.now());

        when(assignmentRepository.findAll()).thenReturn(List.of(assignment));

        // Act
        List<AssignmentDto.AssignmentResponse> responses = assignmentService.getAllAssignments();

        // Assert
        assertThat(responses).isNotEmpty();
        assertThat(responses.get(0).getAssignmentId()).isEqualTo(1L);
        verify(assignmentRepository).findAll();
    }

    @Test
    void testGetAssignmentById() {
        // Arrange
        Assignment assignment = new Assignment();
        assignment.setAssignmentId(1L);
        assignment.setRouteId(1L);
        assignment.setDateAssigned(LocalDate.now());

        when(assignmentRepository.findById(1L)).thenReturn(Optional.of(assignment));

        // Act
        AssignmentDto.AssignmentResponse response = assignmentService.getAssignmentById(1L);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getAssignmentId()).isEqualTo(1L);
        verify(assignmentRepository).findById(1L);
    }

    @Test
    void testGetAssignmentById1ThrowsResourceNotFoundException() {
        // Arrange
        when(assignmentRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.getAssignmentById(1L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Assignment not found with ID: 1");
        verify(assignmentRepository).findById(1L);
    }

    @Test
    void testUpdateAssignment() {
        // Arrange
        AssignmentDto.AssignmentUpdateRequest request = new AssignmentDto.AssignmentUpdateRequest();
        request.setRouteId(2L);

        // Create and set up the vehicle
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setRegistrationNo("ABC123");

        // Create and set up the assignment with the vehicle
        Assignment assignment = new Assignment();
        assignment.setAssignmentId(1L);
        assignment.setRouteId(1L);
        assignment.setDateAssigned(LocalDate.now());
        assignment.setVehicle(vehicle);  // Set the vehicle to prevent NPE

        when(assignmentRepository.findById(1L)).thenReturn(Optional.of(assignment));
        when(assignmentRepository.save(any(Assignment.class))).thenReturn(assignment);

        // Act
        AssignmentDto.AssignmentResponse response = assignmentService.updateAssignment(1L, request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getRouteId()).isEqualTo(2L);
        verify(assignmentRepository).findById(1L);
        verify(assignmentRepository).save(any(Assignment.class));
    }

    @Test
    void testDeleteAssignment() {
        // Arrange
        Assignment assignment = new Assignment();
        assignment.setAssignmentId(1L);

        when(assignmentRepository.findById(1L)).thenReturn(Optional.of(assignment));
        doNothing().when(assignmentRepository).delete(assignment);

        // Act
        assignmentService.deleteAssignment(1L);

        // Assert
        verify(assignmentRepository).findById(1L);
        verify(assignmentRepository).delete(assignment);
    }

    @Test
    void testDeleteAssignmentThrowsResourceNotFoundException() {
        // Arrange
        when(assignmentRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.deleteAssignment(1L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Assignment not found with ID: 1");
        verify(assignmentRepository).findById(1L);
    }
    
    @Test
    void testCreateAssignmentThrowsInvalidRequestException() {
        // Arrange
        AssignmentDto.AssignmentCreateRequest request = new AssignmentDto.AssignmentCreateRequest();
        request.setRouteId(-1L); // Invalid route ID
        request.setDateAssigned(LocalDate.now());
        request.setVehicleId(1L);

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.createAssignment(request))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessageContaining("Invalid Route ID: -1");
        verifyNoInteractions(assignmentRepository, vehicleRepository);
    }

    @Test
    void testCreateAssignmentThrowsResourceNotFoundException() {
        // Arrange
        AssignmentDto.AssignmentCreateRequest request = new AssignmentDto.AssignmentCreateRequest();
        request.setRouteId(1L);
        request.setDateAssigned(LocalDate.now());
        request.setVehicleId(999L); // Non-existent vehicle ID

        when(vehicleRepository.findById(999L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.createAssignment(request))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Vehicle not found with ID: 999");

        // Verify interactions
        verify(vehicleRepository).findById(999L);
        verifyNoMoreInteractions(vehicleRepository); // Ensure no further interactions with vehicleRepository
        // Remove verifyNoInteractions(assignmentRepository) since existsByRouteIdAndDateAssigned is called
    }

    @Test
    void testGetAssignmentsByDate1ThrowsResourceNotFoundException() {
        // Arrange
        LocalDate date = LocalDate.now();
        when(assignmentRepository.findByDateAssigned(date)).thenReturn(List.of());

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.getAssignmentsByDate(date))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("No assignments found for the date");
        verify(assignmentRepository).findByDateAssigned(date);
    }

    @Test
    void testGetAssignmentByIdThrowsResourceNotFoundException() {
        // Arrange
        when(assignmentRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.getAssignmentById(1L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Assignment not found with ID: 1");
        verify(assignmentRepository).findById(1L);
    }

    @Test
    void testUpdateAssignment_RouteUpdate() {
        // Arrange
        AssignmentDto.AssignmentUpdateRequest request = new AssignmentDto.AssignmentUpdateRequest();
        request.setRouteId(2L);

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setRegistrationNo("ABC123");

        Assignment existingAssignment = new Assignment();
        existingAssignment.setAssignmentId(1L);
        existingAssignment.setRouteId(1L);
        existingAssignment.setDateAssigned(LocalDate.now());
        existingAssignment.setVehicle(vehicle);

        when(assignmentRepository.findById(1L)).thenReturn(Optional.of(existingAssignment));
        when(assignmentRepository.findAll()).thenReturn(List.of(existingAssignment));
        when(assignmentRepository.save(any(Assignment.class))).thenReturn(existingAssignment);

        // Act
        AssignmentDto.AssignmentResponse response = assignmentService.updateAssignment(1L, request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getRouteId()).isEqualTo(2L);
        verify(assignmentRepository).findById(1L);
        verify(assignmentRepository).save(any(Assignment.class));
    }

    @Test
    void testUpdateAssignment_VehicleUpdate() {
        // Arrange
        AssignmentDto.AssignmentUpdateRequest request = new AssignmentDto.AssignmentUpdateRequest();
        request.setVehicleId(2L);

        Vehicle oldVehicle = new Vehicle();
        oldVehicle.setVehicleId(1L);
        oldVehicle.setRegistrationNo("ABC123");

        Vehicle newVehicle = new Vehicle();
        newVehicle.setVehicleId(2L);
        newVehicle.setRegistrationNo("XYZ789");

        Assignment existingAssignment = new Assignment();
        existingAssignment.setAssignmentId(1L);
        existingAssignment.setRouteId(1L);
        existingAssignment.setDateAssigned(LocalDate.now());
        existingAssignment.setVehicle(oldVehicle);

        when(assignmentRepository.findById(1L)).thenReturn(Optional.of(existingAssignment));
        when(vehicleRepository.findById(2L)).thenReturn(Optional.of(newVehicle));
        when(assignmentRepository.findAll()).thenReturn(List.of(existingAssignment));
        when(assignmentRepository.save(any(Assignment.class))).thenReturn(existingAssignment);

        // Act
        AssignmentDto.AssignmentResponse response = assignmentService.updateAssignment(1L, request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getVehicleId()).isEqualTo(2L);
        verify(assignmentRepository).findById(1L);
        verify(vehicleRepository).findById(2L);
        verify(assignmentRepository).save(any(Assignment.class));
    }

    @Test
    void testUpdateAssignment_DateUpdate() {
        // Arrange
        LocalDate newDate = LocalDate.now().plusDays(1);
        AssignmentDto.AssignmentUpdateRequest request = new AssignmentDto.AssignmentUpdateRequest();
        request.setDateAssigned(newDate);

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setRegistrationNo("ABC123");

        Assignment existingAssignment = new Assignment();
        existingAssignment.setAssignmentId(1L);
        existingAssignment.setRouteId(1L);
        existingAssignment.setDateAssigned(LocalDate.now());
        existingAssignment.setVehicle(vehicle);

        when(assignmentRepository.findById(1L)).thenReturn(Optional.of(existingAssignment));
        when(assignmentRepository.findAll()).thenReturn(List.of(existingAssignment));
        when(assignmentRepository.save(any(Assignment.class))).thenReturn(existingAssignment);

        // Act
        AssignmentDto.AssignmentResponse response = assignmentService.updateAssignment(1L, request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getDateAssigned()).isEqualTo(newDate);
        verify(assignmentRepository).findById(1L);
        verify(assignmentRepository).save(any(Assignment.class));
    }

    @Test
    void testUpdateAssignment_DuplicateRouteAssignment() {
        // Arrange
        AssignmentDto.AssignmentUpdateRequest request = new AssignmentDto.AssignmentUpdateRequest();
        request.setRouteId(2L);

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setRegistrationNo("ABC123");

        Assignment existingAssignment = new Assignment();
        existingAssignment.setAssignmentId(1L);
        existingAssignment.setRouteId(1L);
        existingAssignment.setDateAssigned(LocalDate.now());
        existingAssignment.setVehicle(vehicle);

        Assignment duplicateAssignment = new Assignment();
        duplicateAssignment.setAssignmentId(2L);
        duplicateAssignment.setRouteId(2L);
        duplicateAssignment.setDateAssigned(LocalDate.now());

        when(assignmentRepository.findById(1L)).thenReturn(Optional.of(existingAssignment));
        when(assignmentRepository.findAll()).thenReturn(List.of(existingAssignment, duplicateAssignment));

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.updateAssignment(1L, request))
                .isInstanceOf(DuplicateResourceException.class)
                .hasMessageContaining("Route 2 is already assigned to a vehicle on date");
    }

    @Test
    void testUpdateAssignment_DuplicateVehicleAssignment() {
        // Arrange
        AssignmentDto.AssignmentUpdateRequest request = new AssignmentDto.AssignmentUpdateRequest();
        request.setVehicleId(2L);

        Vehicle vehicle1 = new Vehicle();
        vehicle1.setVehicleId(1L);
        vehicle1.setRegistrationNo("ABC123");

        Vehicle vehicle2 = new Vehicle();
        vehicle2.setVehicleId(2L);
        vehicle2.setRegistrationNo("XYZ789");

        Assignment existingAssignment = new Assignment();
        existingAssignment.setAssignmentId(1L);
        existingAssignment.setRouteId(1L);
        existingAssignment.setDateAssigned(LocalDate.now());
        existingAssignment.setVehicle(vehicle1);

        Assignment duplicateAssignment = new Assignment();
        duplicateAssignment.setAssignmentId(2L);
        duplicateAssignment.setRouteId(2L);
        duplicateAssignment.setDateAssigned(LocalDate.now());
        duplicateAssignment.setVehicle(vehicle2);

        when(assignmentRepository.findById(1L)).thenReturn(Optional.of(existingAssignment));
        when(vehicleRepository.findById(2L)).thenReturn(Optional.of(vehicle2));
        when(assignmentRepository.findAll()).thenReturn(List.of(existingAssignment, duplicateAssignment));

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.updateAssignment(1L, request))
                .isInstanceOf(DuplicateResourceException.class)
                .hasMessageContaining("Vehicle 2 is already assigned to another route on date");
    }

    @Test
    void testDeleteAssignment1ThrowsResourceNotFoundException() {
        // Arrange
        when(assignmentRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> assignmentService.deleteAssignment(1L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Assignment not found with ID: 1");
        verify(assignmentRepository).findById(1L);
    }
}