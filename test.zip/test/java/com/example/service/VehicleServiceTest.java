package com.example.service;

import com.example.dto.VehicleDto;
import com.example.entity.Assignment;
import com.example.entity.Vehicle;
import com.example.exception.DuplicateResourceException;
import com.example.exception.InvalidRequestException;
import com.example.exception.ResourceNotFoundException;
import com.example.repository.AssignmentRepository;
import com.example.repository.VehicleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

class VehicleServiceTest {

    @Mock
    private VehicleRepository vehicleRepository;

    @Mock
    private AssignmentRepository assignmentRepository;

    @InjectMocks
    private VehicleService vehicleService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateVehicle() {
        // Arrange
        VehicleDto.VehicleCreateRequest request = new VehicleDto.VehicleCreateRequest();
        request.setRegistrationNo("ABC123");
        request.setType("Truck");
        request.setStatus("Available");

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setRegistrationNo("ABC123");
        vehicle.setType("Truck");
        vehicle.setStatus("Available");

        when(vehicleRepository.existsByRegistrationNo("ABC123")).thenReturn(false);
        when(vehicleRepository.save(any(Vehicle.class))).thenReturn(vehicle);

        // Act
        VehicleDto.VehicleResponse response = vehicleService.createVehicle(request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getVehicleId()).isEqualTo(1L);
        assertThat(response.getRegistrationNo()).isEqualTo("ABC123");
        verify(vehicleRepository).existsByRegistrationNo("ABC123");
        verify(vehicleRepository).save(any(Vehicle.class));
    }

    @Test
    void testCreateVehicleThrowsDuplicateResourceException() {
        // Arrange
        VehicleDto.VehicleCreateRequest request = new VehicleDto.VehicleCreateRequest();
        request.setRegistrationNo("ABC123");

        when(vehicleRepository.existsByRegistrationNo("ABC123")).thenReturn(true);

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.createVehicle(request))
                .isInstanceOf(DuplicateResourceException.class)
                .hasMessageContaining("Vehicle with registration number 'ABC123' already exists.");
        
        // Verify the interaction with the mock
        verify(vehicleRepository).existsByRegistrationNo("ABC123");
        verifyNoMoreInteractions(vehicleRepository); // Ensure no further interactions occur
    }

    @Test
    void testGetAllVehicles() {
        // Arrange
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setRegistrationNo("ABC123");
        vehicle.setType("Truck");
        vehicle.setStatus("Available");

        when(vehicleRepository.findAll()).thenReturn(List.of(vehicle));

        // Act
        List<VehicleDto.VehicleResponse> responses = vehicleService.getAllVehicles();

        // Assert
        assertThat(responses).isNotEmpty();
        assertThat(responses.get(0).getVehicleId()).isEqualTo(1L);
        verify(vehicleRepository).findAll();
    }

    @Test
    void testGetVehicleById() {
        // Arrange
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setRegistrationNo("ABC123");
        vehicle.setType("Truck");
        vehicle.setStatus("Available");

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));

        // Act
        VehicleDto.VehicleResponse response = vehicleService.getVehicleById(1L);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getVehicleId()).isEqualTo(1L);
        verify(vehicleRepository).findById(1L);
    }

    @Test
    void testGetVehicleByIdThrowsResourceNotFoundException() {
        // Arrange
        when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.getVehicleById(1L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Vehicle not found with ID: 1");
        verify(vehicleRepository).findById(1L);
    }

    @Test
    void testGetVehicleStatus() {
        // Arrange
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setStatus("Available");

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));

        // Act
        VehicleDto.VehicleStatusResponse response = vehicleService.getVehicleStatus(1L);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getStatus()).isEqualTo("Available");
        verify(vehicleRepository).findById(1L);
    }

    @Test
    void testUpdateVehicle() {
        // Arrange
        VehicleDto.VehicleUpdateRequest request = new VehicleDto.VehicleUpdateRequest();
        request.setRegistrationNo("XYZ789");
        request.setType("Van");

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setRegistrationNo("ABC123");
        vehicle.setType("Truck");

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));
        when(vehicleRepository.existsByRegistrationNo("XYZ789")).thenReturn(false);
        when(vehicleRepository.save(any(Vehicle.class))).thenReturn(vehicle);

        // Act
        VehicleDto.VehicleResponse response = vehicleService.updateVehicle(1L, request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getRegistrationNo()).isEqualTo("XYZ789");
        assertThat(response.getType()).isEqualTo("Van");
        verify(vehicleRepository).findById(1L);
        verify(vehicleRepository).existsByRegistrationNo("XYZ789");
        verify(vehicleRepository).save(any(Vehicle.class));
    }

    @Test
    void testUpdateVehicleStatus() {
        // Arrange
        VehicleDto.VehicleStatusUpdateRequest request = new VehicleDto.VehicleStatusUpdateRequest();
        request.setNewStatus("Inactive");

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setStatus("Available");

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));
        when(vehicleRepository.save(any(Vehicle.class))).thenReturn(vehicle);

        // Act
        VehicleDto.VehicleResponse response = vehicleService.updateVehicleStatus(1L, request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getStatus()).isEqualTo("Inactive");
        verify(vehicleRepository).findById(1L);
        verify(vehicleRepository).save(any(Vehicle.class));
    }

    @Test
    void testTransferAndDeleteVehicle() {
        // Arrange
        Vehicle fromVehicle = new Vehicle();
        fromVehicle.setVehicleId(1L);

        Vehicle toVehicle = new Vehicle();
        toVehicle.setVehicleId(2L);

        Assignment assignment = new Assignment();
        assignment.setAssignmentId(1L);
        assignment.setVehicle(fromVehicle);

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(fromVehicle));
        when(vehicleRepository.findById(2L)).thenReturn(Optional.of(toVehicle));
        when(assignmentRepository.findByVehicle(fromVehicle)).thenReturn(List.of(assignment));

        // Act
        vehicleService.transferAndDeleteVehicle(1L, 2L);

        // Assert
        verify(vehicleRepository).findById(1L);
        verify(vehicleRepository).findById(2L);
        verify(assignmentRepository).findByVehicle(fromVehicle);
        verify(assignmentRepository).save(any(Assignment.class));
        verify(vehicleRepository).delete(fromVehicle);
    }

    @Test
    void testTransferAndDeleteVehicleThrowsInvalidRequestException() {
        // Arrange
        Vehicle fromVehicle = new Vehicle();
        fromVehicle.setVehicleId(1L);

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(fromVehicle));
        when(assignmentRepository.findByVehicle(fromVehicle)).thenReturn(List.of(new Assignment()));

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.transferAndDeleteVehicle(1L, null))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessageContaining("Target vehicle ID must not be null when transferring assignments.");
        verify(vehicleRepository).findById(1L);
        verify(assignmentRepository).findByVehicle(fromVehicle);
    }
    
    @Test
    void testCreateVehicle1ThrowsDuplicateResourceException() {
        // Arrange
        VehicleDto.VehicleCreateRequest request = new VehicleDto.VehicleCreateRequest();
        request.setRegistrationNo("ABC123");

        when(vehicleRepository.existsByRegistrationNo("ABC123")).thenReturn(true);

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.createVehicle(request))
                .isInstanceOf(DuplicateResourceException.class)
                .hasMessageContaining("Vehicle with registration number 'ABC123' already exists.");
        verify(vehicleRepository).existsByRegistrationNo("ABC123");
        verifyNoMoreInteractions(vehicleRepository);
    }

    @Test
    void testGetVehicleById1ThrowsResourceNotFoundException() {
        // Arrange
        when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.getVehicleById(1L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Vehicle not found with ID: 1");
        verify(vehicleRepository).findById(1L);
    }

    @Test
    void testGetVehicleStatusThrowsResourceNotFoundException() {
        // Arrange
        when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.getVehicleStatus(1L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Vehicle not found with ID: 1");
        verify(vehicleRepository).findById(1L);
    }

    @Test
    void testUpdateVehicleThrowsResourceNotFoundException() {
        // Arrange
        VehicleDto.VehicleUpdateRequest request = new VehicleDto.VehicleUpdateRequest();
        request.setRegistrationNo("XYZ789");

        when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.updateVehicle(1L, request))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Vehicle not found with ID: 1");
        verify(vehicleRepository).findById(1L);
    }

    @Test
    void testUpdateVehicleThrowsDuplicateResourceException() {
        // Arrange
        VehicleDto.VehicleUpdateRequest request = new VehicleDto.VehicleUpdateRequest();
        request.setRegistrationNo("XYZ789");

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1L);
        vehicle.setRegistrationNo("ABC123");

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));
        when(vehicleRepository.existsByRegistrationNo("XYZ789")).thenReturn(true);

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.updateVehicle(1L, request))
                .isInstanceOf(DuplicateResourceException.class)
                .hasMessageContaining("Vehicle with registration number 'XYZ789' already exists.");
        verify(vehicleRepository).findById(1L);
        verify(vehicleRepository).existsByRegistrationNo("XYZ789");
    }

    @Test
    void testUpdateVehicleStatusThrowsResourceNotFoundException() {
        // Arrange
        VehicleDto.VehicleStatusUpdateRequest request = new VehicleDto.VehicleStatusUpdateRequest();
        request.setNewStatus("Inactive");

        when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.updateVehicleStatus(1L, request))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Vehicle not found with ID: 1");
        verify(vehicleRepository).findById(1L);
    }

    @Test
    void testTransferAndDeleteVehicleSuccessfullyTransfersAssignments() {
        // Arrange
        Vehicle fromVehicle = new Vehicle();
        fromVehicle.setVehicleId(1L);

        Vehicle toVehicle = new Vehicle();
        toVehicle.setVehicleId(2L);

        Assignment assignment = new Assignment();
        assignment.setAssignmentId(1L);
        assignment.setVehicle(fromVehicle);

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(fromVehicle));
        when(vehicleRepository.findById(2L)).thenReturn(Optional.of(toVehicle));
        when(assignmentRepository.findByVehicle(fromVehicle)).thenReturn(List.of(assignment));

        // Act
        vehicleService.transferAndDeleteVehicle(1L, 2L);

        // Assert
        verify(vehicleRepository).findById(1L);
        verify(vehicleRepository).findById(2L);
        verify(assignmentRepository).findByVehicle(fromVehicle);
        verify(assignmentRepository).save(any(Assignment.class));
        verify(vehicleRepository).delete(fromVehicle);
    }

    @Test
    void testTransferAndDeleteVehicleDeletesVehicleWithoutAssignments() {
        // Arrange
        Vehicle fromVehicle = new Vehicle();
        fromVehicle.setVehicleId(1L);

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(fromVehicle));
        when(assignmentRepository.findByVehicle(fromVehicle)).thenReturn(List.of());

        // Act
        vehicleService.transferAndDeleteVehicle(1L, null);

        // Assert
        verify(vehicleRepository).findById(1L);
        verify(assignmentRepository).findByVehicle(fromVehicle);
        verify(vehicleRepository).delete(fromVehicle);
        //verifyNoInteractions(assignmentRepository);
    }

    @Test
    void testTransferAndDeleteVehicleThrowsResourceNotFoundExceptionForSourceVehicle() {
        // Arrange
        when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.transferAndDeleteVehicle(1L, 2L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Vehicle not found with ID: 1");

        verify(vehicleRepository).findById(1L);
        verifyNoInteractions(assignmentRepository);
    }

    @Test
    void testTransferAndDeleteVehicleThrowsInvalidRequestExceptionWhenTargetVehicleIdIsNull() {
        // Arrange
        Vehicle fromVehicle = new Vehicle();
        fromVehicle.setVehicleId(1L);

        Assignment assignment = new Assignment();
        assignment.setAssignmentId(1L);
        assignment.setVehicle(fromVehicle);

        when(vehicleRepository.findById(1L)).thenReturn(Optional.of(fromVehicle));
        when(assignmentRepository.findByVehicle(fromVehicle)).thenReturn(List.of(assignment));

        // Act & Assert
        assertThatThrownBy(() -> vehicleService.transferAndDeleteVehicle(1L, null))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessageContaining("Target vehicle ID must not be null when transferring assignments.");

        verify(vehicleRepository).findById(1L);
        verify(assignmentRepository).findByVehicle(fromVehicle);
        //verifyNoInteractions(vehicleRepository);
    }
}